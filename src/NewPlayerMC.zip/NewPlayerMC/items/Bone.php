<?php


namespace NewPlayerMC\items;


use pocketmine\item\Item;

class Bone extends \pocketmine\item\Item
{
    public function __construct()
    {
        parent::__construct(352, 0, "Epée en Itérium");
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }

}