<?php


namespace NewPlayerMC\items;


class Spacecake extends \pocketmine\item\CookedSalmon
{
    public function getMaxStackSize(): int
    {
        return 2;
    }
}