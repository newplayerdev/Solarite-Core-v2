<?php


namespace NewPlayerMC\Solarite;


use NewPlayerMC\armors\BottesIterium;
use NewPlayerMC\armors\BottesSolarite;
use NewPlayerMC\armors\BottesTopaze;
use NewPlayerMC\armors\CasqueIterium;
use NewPlayerMC\armors\CasqueSolarite;
use NewPlayerMC\armors\CasqueTopaze;
use NewPlayerMC\armors\EpeeIterium;
use NewPlayerMC\armors\EpeeSolarite;
use NewPlayerMC\armors\JambieresIterium;
use NewPlayerMC\armors\JambieresSolarite;
use NewPlayerMC\armors\JambieresTopaze;
use NewPlayerMC\armors\PlastronIterium;
use NewPlayerMC\armors\PlastronSolarite;
use NewPlayerMC\armors\PlastronTopaze;
use NewPlayerMC\armors\SwordTop;
use NewPlayerMC\commands\AdminKit;
use NewPlayerMC\commands\atm\ATMCommand;
use NewPlayerMC\commands\atm\UpgradeCommand;
use NewPlayerMC\commands\boxs\Box;
use NewPlayerMC\commands\boxs\Key;
use NewPlayerMC\commands\Broacast;
use NewPlayerMC\commands\Cheque;
use NewPlayerMC\commands\Cheques;
use NewPlayerMC\commands\ClearInv;
use NewPlayerMC\commands\ClearLag;
use NewPlayerMC\commands\Ec;
use NewPlayerMC\commands\Feed;
use NewPlayerMC\commands\Furnace;
use NewPlayerMC\commands\gamemode\GmcCmd;
use NewPlayerMC\commands\gamemode\GmsCmd;
use NewPlayerMC\commands\gamemode\GmspcCmd;
use NewPlayerMC\commands\GiveAll;
use NewPlayerMC\commands\gmc;
use NewPlayerMC\commands\Heal;
use NewPlayerMC\commands\Near;
use NewPlayerMC\commands\Repair;
use NewPlayerMC\commands\Rtp;
use NewPlayerMC\commands\SpawnBoss;
use NewPlayerMC\commands\Top;
use NewPlayerMC\commands\Tpa;
use NewPlayerMC\commands\Tpall;
use NewPlayerMC\commands\Tps;
use NewPlayerMC\commands\warps\tasks\FfaTask;
use NewPlayerMC\commands\warps\tasks\MinageTask;
use NewPlayerMC\commands\warps\tasks\SpawnTask;
use NewPlayerMC\events\BlockBreakListener;
use NewPlayerMC\events\CraftListener;
use NewPlayerMC\events\EatListener;
use NewPlayerMC\events\Halloween\CitrouilleHead;
use NewPlayerMC\events\Halloween\DropItemListener;
use NewPlayerMC\events\InteractListener;
use NewPlayerMC\events\JoinListener;
use NewPlayerMC\commands\fakes\FakeLeave;
use NewPlayerMC\events\PoseBlockListener;
use NewPlayerMC\events\SpaceCakeListener;
use NewPlayerMC\events\SwordIterium;
use NewPlayerMC\events\SwordSolarite;
use NewPlayerMC\events\SwordTopaze;
use NewPlayerMC\items\Bandage;
use NewPlayerMC\items\Bone;
use NewPlayerMC\items\Hammer;
use NewPlayerMC\items\HangGlider;
use NewPlayerMC\items\LuckyTopaze;
use NewPlayerMC\items\NautlilusShell;
use NewPlayerMC\commands\fakes\FakeJoin;
use NewPlayerMC\items\Seringue;
use NewPlayerMC\items\ShulkerShell;
use NewPlayerMC\items\Spacecake;
use NewPlayerMC\items\Test;
use NewPlayerMC\items\TestItem;
use NewPlayerMC\items\TurtleShell;
use NewPlayerMC\tasks\ATM;
use NewPlayerMC\tasks\LowHealthTask;
use NewPlayerMC\tasks\MoneyTask;
use NewPlayerMC\tasks\MoneyTasks;
use NewPlayerMC\tasks\MessagesTask;
use NewPlayerMC\tasks\OreRain;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\item\ItemFactory;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use jojoe77777\FormAPI;

class  Main extends PluginBase implements Listener
{

    public function onEnable()
    {


        $this->getLogger()->info("§3SolariteCore §6enabled");

        //[Levels]\\
        $this->getServer()->loadLevel("map2f");
        $this->getServer()->loadLevel("map2m2");
        $this->getServer()->loadLevel("map2ffa");

        @mkdir($this->getDataFolder());
        $this->saveResource('config.yml');
        $this->config = new Config($this->getDataFolder().'config.yml', Config::YAML);

        //[Commands]\\
        $this->getServer()->getCommandMap()->registerAll("commands", [
            new Feed("feed", "Régénérer votre barre de faim", "feed"),
            new Repair("repair", "Réparer vos items", "repair [all]", ['repair']),
            new Ec("ec", "Ouvrir votre enderchest", "ec", ['ender', 'echest']),
            new Furnace("furnace", "Faire cuire vos items", "furnace [all]"),
            new ClearInv("clear", "clear l'inventaire", "clear"),
            new Rtp("rtp", "Vous téléporter à un enndroit aléatoire", "rtp", ['wild', 'randomtp']),
            new FakeLeave("leave",  "simuler un message de deconnexion", "leave"),
            new FakeJoin("join", "simuler un message de connexion", "join"),
            new Tps("tps", "Voir les tps du serveur", "tps", ['TPS']),
            new Top("top", "Vous téléporter à la surface", "top"),
            new Broacast("broadcast", "Envoyer un message à tout le monde", "broadcast <message>", ['bc']),
            new GmcCmd("gmc", "Changer votre mode de jeu en créatif", "gmc"),
            new GmsCmd("gms", "Changer votre mode de jeu en survie", "gms"),
            new GmspcCmd("gmspc", "Changer votre mode de jeu en spectateur", "gmspc"),
            new Cheque("cheque", "Créer un chèque", "cheque <prix>"),
            new Box("box", "Ouvrir une box", "box"),
            new Key("key", "Recevoir une key", "key [joueur] [nombre] [type]")
        ]);
        $this->getServer()->getCommandMap()->register("clearlag", new ClearLag($this));
        $this->getServer()->getCommandMap()->register("tpall", new Tpall($this));
        $this->getServer()->getCommandMap()->register("giveall", new GiveAll($this));
        $this->getServer()->getCommandMap()->register("atm", new  ATMCommand($this));
        $this->getServer()->getCommandMap()->register("upgrade", New UpgradeCommand($this));

        //[Events\\
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getPluginManager()->registerEvents(new SpaceCakeListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new EatListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new BlockBreakListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new PoseBlockListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new JoinListener($this), $this);
        $this->getServer()->getPluginManager()->registerEvents(new InteractListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new HangGlider(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new SwordIterium(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new SwordSolarite(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new CitrouilleHead(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new DropItemListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new Seringue(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new Bandage(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new LuckyTopaze(), $this);

        //[Items]\\
        ItemFactory::registerItem(new Hammer(), true);
        ItemFactory::registerItem(new Bone(), true);
        ItemFactory::registerItem(new NautlilusShell(), true);
        ItemFactory::registerItem(new ShulkerShell(), true);
        ItemFactory::registerItem(new TurtleShell(), true);
        ItemFactory::registerItem(new Spacecake(), true);

        //[Armures]\\
        ItemFactory::registerItem(new BottesIterium(), true);
        ItemFactory::registerItem(new BottesSolarite(), true);
        ItemFactory::registerItem(new BottesTopaze(), true);
        ItemFactory::registerItem(new CasqueIterium(), true);
        ItemFactory::registerItem(new CasqueSolarite(), true);
        ItemFactory::registerItem(new CasqueTopaze(), true);
        ItemFactory::registerItem(new JambieresIterium(), true);
        ItemFactory::registerItem(new JambieresSolarite(), true);
        ItemFactory::registerItem(new JambieresTopaze(), true);
        ItemFactory::registerItem(new PlastronIterium(), true);
        ItemFactory::registerItem(new PlastronSolarite(), true);
        ItemFactory::registerItem(new PlastronTopaze(), true);

        //[Tasks]\\
        $this->getScheduler()->scheduleRepeatingTask(new MessagesTask($this), 20*rand(600, 1200));
        $this->getScheduler()->scheduleRepeatingTask(new ATM($this), 20*30);
        $this->getScheduler()->scheduleRepeatingTask(new LowHealthTask($this), 20);
    }

    public function onCommand(CommandSender $player, Command $command, string $label, array $args): bool
    {
        $api = $this->getServer()->getPluginManager()->getPlugin("AdvancedKits");
        switch ($command->getName()) {
            case "spawn":
                $this->getScheduler()->scheduleRepeatingTask(new SpawnTask($this, $player), 20);
                $this->getScheduler()->scheduleRepeatingTask(new OreRain($this), 20);
                break;
            case "minage":
                $this->getScheduler()->scheduleRepeatingTask(new MinageTask($this, $player), 20);
                break;
            case "ffa":
                $this->getScheduler()->scheduleRepeatingTask(new FfaTask($this, $player), 20);
                break;
            case "kitsolarium":
                if(count($args) < 1) {
                    $player->sendMessage("§cMerci de respecter le nombre d'arguments à fournir");
                    return false;
                }

                $name = strtolower(array_shift($args));
                $playr = $player->getServer()->getPlayer($name);
                if ($playr instanceof Player) {
                    $kit = $api->getKit("Solarium");
                    $kit->handleRequest($playr);
                    $player->sendMessage('Tu as donné le kit §6Solarium §fa §6' . $playr->getName());
                } else {
                    $player->sendMessage("§cLe joueur n'existe pas ou ne s'est jamais connecté!");
                }
                break;
            case "kithero":
                if(count($args) < 1) {
                    $player->sendMessage("§cMerci de respecter le nombre d'arguments à fournir");
                    return false;
                }

                $name = strtolower(array_shift($args));
                $playr = $player->getServer()->getPlayer($name);
                if ($playr instanceof Player) {
                    $kit = $api->getKit("Hero");
                    $kit->handleRequest($playr);
                    $player->sendMessage('Tu as donné le kit §6Hero §fa §6' . $playr->getName());
                } else {
                    $player->sendMessage("§cLe joueur n'existe pas ou ne s'est jamais connecté!");
                }
                break;
            case "kitvip":
                if(count($args) < 1) {
                    $player->sendMessage("§cMerci de respecter le nombre d'arguments à fournir");
                    return false;
                }

                $name = strtolower(array_shift($args));
                $playr = $player->getServer()->getPlayer($name);
                if ($playr instanceof Player) {
                    $kit = $api->getKit("VIP");
                    $kit->handleRequest($playr);
                    $player->sendMessage('Tu as donné le kit §6VIP §fa §6' . $playr->getName());
                } else {
                    $player->sendMessage("§cLe joueur n'existe pas ou ne s'est jamais connecté!");
                }
                break;
            case "kitjoueur":
                if(count($args) < 1) {
                    $player->sendMessage("§cMerci de respecter le nombre d'arguments à fournir");

                    return false;

                }

                $name = strtolower(array_shift($args));
                $playr = $player->getServer()->getPlayer($name);
                if ($playr instanceof Player) {
                    $kit = $api->getKit("Joueur");
                    $kit->handleRequest($playr);
                    $player->sendMessage('Tu as donné le kit §6Joueur §fa §6' . $playr->getName());
                } else {
                    $player->sendMessage("§cLe joueur n'existe pas ou ne s'est jamais connecté!");
                }
                break;
        }
        return true;
    }

}