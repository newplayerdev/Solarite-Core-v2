<?php


namespace NewPlayerMC\events;


use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\block\BlockIds;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;
use pocketmine\item\Tool;
use pocketmine\item\Totem;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\sound\AnvilBreakSound;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\IntTag;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\tile\EnderChest;
use pocketmine\tile\Tile;

class InteractListener implements Listener
{

    public $cooldown = [];
    public $stickCoolDown = [];

    public function onInteract(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if($item->getId() === ItemIds::PAPER){
            $lore = $item->getLore();
            if(intval($lore[0])){
                EconomyAPI::getInstance()->addMoney($player,intval($lore[0]));
                $p = intval($lore[0]);
                $player->sendMessage("§c$p $ ont été ajouté(s) ");
                $player->getInventory()->remove($item);
            }
        }
        $block = $event->getBlock();
        $obsidian = Item::get(131, 0, 1);
        $level = $player->getLevel();

        if ($item->getId() == 437 && $block->getId() === 49) {

            $lvl = $player->getLevel();
            $lvl->setBlock(new Vector3($block->getX(), $block->getY(), $block->getZ()), Block::get(0, 0));
            $tag = $item->getNamedTag();
            $dura =  $tag->hasTag("dura", IntTag::class) ? $tag->getInt("dura") + 1: 1;
            $tag ->setInt("dura",$dura );
            $item->setLore(["§r§f{$dura}§7/§f10"]);
            $item->setNamedTag($tag);
        }


        if ($item->getId() == 351 && $item->getDamage() == 8) {
            if (!isset($this->cooldown[$player->getName()])) {
                $this->cooldown[$player->getName()] = time() + 180;
                foreach ($player->getInventory()->getContents() as $index => $item) {
                    if ($item instanceof Tool || $item instanceof Armor) {
                        if ($item->getDamage() > 0) {
                            $player->getInventory()->setItem($index, $item->setDamage(0));
                            $item->getMaxDurability();
                            $item->setDamage($item->getMaxDurability() - 1);

                        }
                    }
                }

                foreach ($player->getArmorInventory()->getContents() as $index => $item) {
                    if ($item instanceof Tool || $item instanceof Armor) {
                        if ($item->getDamage() > 0) {
                            $player->getArmorInventory()->setItem($index, $item->setDamage(0));
                        }
                    }
                }
                $player->sendPopup("§aTes items ont bien été réparé");
                $minX = $player->x - 1;
                $maxX = $player->x + 1;

                $minY = $player->y - 1;
                $maxY = $player->y + 1;

                $minZ = $player->z - 1;
                $maxZ = $player->z + 1;

                for ($x = $minX; $x <= $maxX; $x++) {

                    for ($y = $minY; $y <= $maxY; $y++) {

                        for ($z = $minZ; $z <= $maxZ; $z++) {

                            $player->getLevel()->addParticle(new HeartParticle(new Vector3($x, $y, $z)));
                        }

                    }

                }
            } else {
                if (time() < $this->cooldown[$player->getName()]) {
                    $remaining = $this->cooldown[$player->getName()] - time();

                } else {
                    unset($this->cooldown[$player->getName()]);
                }

            }
        }
        if ($item->getId() == 375) {
            if (!isset($this->stickCoolDown[$player->getName()])) {
                $this->stickCoolDown[$player->getName()] = time() + 120;
                $player->addEffect(new EffectInstance(Effect::getEffect(Effect::HEALTH_BOOST), 20 * 30, 1));
                $player->addEffect(new EffectInstance(Effect::getEffect(Effect::ABSORPTION), 20 * 30, 1));
                $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20 * 30, 2));
                $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 30, 2));

                $player->setHealth(50);
            } else {
                if (time() < $this->stickCoolDown[$player->getName()]) {
                    $remaining = $this->stickCoolDown[$player->getName()] - time();
                    $player->sendPopup("§cCooldown: " . $remaining . " secondes");
                } else {
                    unset($this->stickCoolDown[$player->getName()]);
                }

            }
        } elseif ($item->getId() === 369) {
            if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                if (!isset($this->boostCooldown[$player->getName()])) {
                    $this->boostCooldown[$player->getName()] = time() + 120;
                    $level->addSound(new AnvilBreakSound(new Vector3($player->getX(), $player->getY(), $player->getZ())));
                    $level->addParticle(new FlameParticle(new Vector3($player->getX(), $player->getY(), $player->getZ())));
                    $player->setMotion($player->getDirectionVector()->multiply(5));
                    $player->jump();
                } else {
                    if (time() < $this->boostCooldown[$player->getName()]) {
                        $remaining = $this->boostCooldown[$player->getName()] - time();
                        $player->sendPopup("§cCooldown: " . $remaining . " secondes");
                    } else {
                        unset($this->boostCooldown[$player->getName()]);
                    }
                }
            }
        } elseif ($item->getId() === 467) {
            $block = BlockFactory::get(BlockIds::ENDER_CHEST);
            $block->x = (int)$player->x;
            $block->y = (int)$player->y;
            $block->z = (int)$player->z;
            $block->level = $player->level;
            $player->getLevel()->sendBlocks([$player], [$block]);
            $tile = Tile::createTile(Tile::ENDER_CHEST, $block->getLevel(), EnderChest::createNBT($block));
            $player->getEnderChestInventory()->setHolderPosition($tile);
            $player->addWindow($player->getEnderChestInventory());
        }
    }
}