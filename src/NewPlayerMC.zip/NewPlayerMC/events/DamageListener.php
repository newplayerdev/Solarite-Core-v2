<?php


namespace NewPlayerMC\events;


use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\Player;

class DamageListener implements Listener
{

    public function onDamage(EntityDamageEvent $event) {

        $player = $event->getEntity();

        if($player instanceof Player){
            if($event->getEntity()->getInventory()->getItemInHand()->getId() === 415){
                if ($event->getCause() === EntityDamageEvent::CAUSE_FALL){

                    $event->setCancelled();

                } else {
                }
            }
            if ($event->getEntity()->getInventory()->getItemInHand()->getId() === 369) {
                if ($event->getCause() === EntityDamageEvent::CAUSE_FALL){

                    $event->setCancelled();

                } else {
                }
            } else {
            }
        } else {
        }
    }

}