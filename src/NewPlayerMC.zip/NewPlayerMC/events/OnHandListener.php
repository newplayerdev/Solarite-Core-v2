<?php


namespace NewPlayerMC\events;


use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\item\Item;

class OnHandListener implements Listener
{
    public function onHand(PlayerItemHeldEvent $event) {
        $player = $event->getPlayer();
        $item = $event->getItem();
        if($item->getId() == Item::RABBIT_HIDE){

            $eff = new EffectInstance(Effect::getEffect(Effect::LEVITATION), 100 * 99999, -3, true);
            $player->addEffect($eff);

        } else if (($player->hasEffect(Effect::LEVITATION)) and (!$item->getId() == Item::RABBIT_HIDE)){

            $player->removeEffect(24);

        } else {
            $player->removeEffect(24);

        }
    }

}