<?php

namespace NewPlayerMC\events;

use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemConsumeEvent;;

class EatListener implements Listener
{

    public function onEat(PlayerItemConsumeEvent $event) {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if($item->getId() === 357) {
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::HEALTH_BOOST), 20*30, 2));
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20*20, 1));
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::ABSORPTION), 20*20, 0));
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 20*30, 1));
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20*30, 1));
            $player->addFood(5);
        } elseif ($item->getId() === 350) {
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20*15, 1));
            $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20*20, 1));
        }
    }

}