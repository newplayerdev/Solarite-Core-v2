<?php


namespace NewPlayerMC\events;


use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;

class PoseBlockListener implements Listener
{
    public function onPose(BlockPlaceEvent $event)
    {
        $block = $event->getBlock();
        $item = $event->getItem();
        $player = $event->getPlayer();

        if($block->getId() === 54) {
            if($player->getLevel()->getName() === "map2m2") {
                $event->setCancelled(true);
                $player->sendMessage("§cTu n'as pas le droit de poser ce bloc en minage");
            }
        }
        if($item->getCustomName() === "§cTerre de la loose") {
            $event->setCancelled(true);
        }
    }

}