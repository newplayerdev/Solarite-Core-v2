<?php


namespace NewPlayerMC\events;


use NewPlayerMC\Solarite\Main;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\Server;
use pocketmine\utils\Config;

class JoinListener implements Listener
{
    public $plugin;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function onJoin(PlayerJoinEvent $event)
   {
       $player = $event->getPlayer();
       if(!$player->hasPlayedBefore())
       {
           $config = new Config($this->plugin->getDataFolder() . "config.yml", Config::YAML, array(
               $player->getName() => [
                   "atm" => 1 ,
                   "rank" => "normal"
               ]
           ));
           $config->save();
           $event->setJoinMessage("§b» §6" . $player->getName() . " §fa rejoins pour la première fois le serveur!\n§eSouhaitez lui la bienvenue!");
       } else {
           $event->setJoinMessage(" ");
           Server::getInstance()->broadcastPopup("§a+ [§6" . $player->getName() . "§a]");
       }
   }

   public function onLeave(PlayerQuitEvent $event)
   {

       $player = $event->getPlayer();
       $item = $player->getInventory()->getItemInHand();

       if($item->getId() == Item::BLAZE_POWDER){
           $player->removeEffect(24);
       }
       $event->setQuitMessage(" ");
       Server::getInstance()->broadcastPopup("§c- [§6" . $player->getName() . "§c]");
   }

   public function onPreLogin(PlayerPreLoginEvent $event) {

       if(!$event->getPlayer()->isWhitelisted()) {
           $event->setKickMessage("§cLe serveur est actuelement en maitenance pour la §bV2\n\n---------------[§6On revient bientôt!§f]---------------");
           $event->setCancelled(true);
       }
   }
}