<?php


namespace NewPlayerMC\events;


use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;

class SpaceCakeListener implements \pocketmine\event\Listener
{
    public function onUse(PlayerItemConsumeEvent $ev) {
        $item = $ev->getItem();
        if($item->getId() === ItemIds::COOKED_SALMON) {
              $ev->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::NAUSEA), 20*35, 3, false));
              $ev->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20*35, 3, false));
              $ev->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::LEVITATION), 20*35, -3, false));
              $ev->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 20*35, 0.5, false));
        }
    }

}