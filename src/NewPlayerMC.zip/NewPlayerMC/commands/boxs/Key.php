<?php


namespace NewPlayerMC\commands\boxs;


use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use pocketmine\event\player\PlayerEditBookEvent;
use pocketmine\item\Item;
use pocketmine\Player;

class Key extends \pocketmine\command\Command
{

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if (!$sender->hasPermission("key.core.use")) {
                $sender->sendMessage("§cTu n'as pas la permission d'utiliser cette commande");
            }
            if (count($args) < 2) {
                $sender->sendMessage("Usage: /key [joueur] [nombre] [type]");
                return;
            }

            $player = $sender->getServer()->getPlayer($args[0]);
            if ($player instanceof Player) {

            if ($player->getInventory()->canAddItem(Item::get(Item::NAME_TAG, 0, $args[1]))) {
                $player->getInventory()->addItem(Item::get(Item::NAME_TAG, 0, $args[1])->setLore(['Key ' . $args[2]]));
                $player->sendMessage("§aTu as reçu " . $args[1] . " key(s) " . $args[2]);
            } else {
                $sender->sendMessage("§cTon inventaire est plein");
             }
            } else {
                $sender->sendMessage("§cCe jouer n'existe pas ou ne s'est jamais connecté");
            }
          }
       }
}