<?php


namespace NewPlayerMC\commands\warps\tasks;


use NewPlayerMC\Solarite\Main;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\level\particle\PortalParticle;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class SpawnTask extends Task implements Listener
{
    public $player;
    private $plugin;
    public $cl = 3;


    public function __construct(Main $plugin,Player $player)
    {
        $this->plugin = $plugin;
        $this->player = $player;
    }

    public function onRun(int $tick)
    {
        if ($this->player instanceof Player) {
            if ($this->cl > 0) {
                $this->player->sendPopup("§aTéléportation en cours...§f\n§7Merci de ne pas bouger pendant la téléportation");
                $this->player->getLevel()->addParticle(new PortalParticle(new Vector3($this->player->x, $this->player->y, $this->player->z)));
                $this->player->addEffect(new EffectInstance(Effect::getEffect(Effect::NAUSEA), 20*3, 1, false));

            } else {
                $this->player->teleport($this->player->getServer()->getDefaultLevel()->getSafeSpawn());
                $this->player->sendMessage("§fTu as bien été téléporté au spawn! §c«");
                $this->plugin->getScheduler()->cancelTask($this->getTaskId());
            }
        $this->cl--;
    }
 }


}