<?php


namespace NewPlayerMC\commands;


use NewPlayerMC\Solarite\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class Rtp extends Command
{
    public $plugin;

    public function __construct(string $name, string $description = "", string $usageMessage = null, array $aliases = [])
    {
        parent::__construct($name, $description, $usageMessage, $aliases);
    }

    public function execute(CommandSender $player, string $commandLabel, array $args)
    {
        if(!$player instanceof Player) {
            $player->sendMessage("§cCette commande est à faire en jeu!");
            return false;
        }
        if(!$player->getLevel()->getName() === "map2f") {
            $player->sendMessage("Tu ne peux pas faire cette commande dans ce monde");
            return false;
        }
        
        $player->teleport(Server::getInstance()->getLevelByName("map2f")->getSafeSpawn(new Vector3(rand(rand(2300, -2300), rand(-2300, 2300)), rand(70, 100), rand(rand(2300, -2300), rand(-2300, 2300)))));
        $player->sendMessage("§aTu as bien été téléporté");
        return true;
    }

}