<?php


namespace NewPlayerMC\commands;


use NewPlayerMC\Solarite\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;

class Top extends Command
{
    public function __construct(string $name, string $description = "", string $usageMessage = null, array $aliases = [])
    {
        parent::__construct($name, $description, $usageMessage, $aliases);
    }

    public function execute(CommandSender $player, string $commandLabel, array $args)
    {
        if($player instanceof Player) {
            if(!$player->hasPermission("top.use")) {
                $player->sendMessage("§cVous n'avez pas la permission d'utiliser cette commande.");
            }
            $x = $player->getX();
            $z = $player->getZ();
            $y = $player->getLevel()->getHighestBlockAt($x, $z);
            $player->teleport(new Position($x, $y, $z, $player->getLevel()));
         }
        return true;
    }


}