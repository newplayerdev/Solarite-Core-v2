<?php


namespace NewPlayerMC\tasks;


use Cassandra\Type;
use NewPlayerMC\Solarite\Main;
use pocketmine\Server;
use pocketmine\utils\Config;

class ATM extends \pocketmine\scheduler\Task
{
    public $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(int $currentTick)
    {

       foreach($this->plugin->getServer()->getOnlinePlayers() as $p) {
        $this->plugin->getConfig()->set($this->plugin->getConfig()->getAll()[$p->getName()]["atm"], $this->plugin->getConfig()->getAll()[$p->getName()]["atm"] + 1);
        $p->sendPopup("+§61$ §fsur l'ATM");
       }
    }
}