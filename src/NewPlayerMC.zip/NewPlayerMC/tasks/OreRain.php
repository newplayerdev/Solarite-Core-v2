<?php


namespace NewPlayerMC\tasks;


use NewPlayerMC\Solarite\Main;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;

class OreRain extends \pocketmine\scheduler\Task
{
    public $player;

    public function __construct(Player $player) {
        $this->player = $player;
    }
    public function onRun(int $currentTick)
    {
        $ores = [
          Item::get(Item::DIAMOND),
          Item::get(Item::IRON_INGOT),
          Item::get(Item::COAL),
          Item::get(Item::GOLD_INGOT)
        ];
        $rands = mt_rand(1, 100);
        $items = $ores;
        if($rands >= 1 && $rands <= 1) {
            $items = 3;
        } elseif($rands >= 2 && $rands <= 20) {
            $items = 0;
        } elseif($items >= 20 && $rands <= 40) {
            $items = 1;
        } elseif($items >= 40 && $rands <= 100) {
            $items = 2;
        }
        $this->player->getLevel()->dropItem(new Vector3($this->player->getX(), $this->player->getY() +  2, $this->player->getZ()), $items, null, 3);
    }
}