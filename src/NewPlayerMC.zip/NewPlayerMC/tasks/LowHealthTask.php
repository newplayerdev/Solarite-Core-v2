<?php


namespace NewPlayerMC\tasks;


use NewPlayerMC\Solarite\Main;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class LowHealthTask extends Task
{

    public $plugin;
    public $player;

    public function __construct(Main $plugin, Player $player)
    {
        $this->plugin = $plugin;
        $this->player = $player;
    }

    public function onRun(int $currentTick)
    {
       if($this->player->getHealth() <= 1) {
           $this->player->setSneaking(true);
           $this->player->setNameTagAlwaysVisible(true);
       } else {
           $this->plugin->getScheduler()->cancelTask($this->getTaskId());
       }
    }
}