<?php


namespace NewPlayerMC\armors;


use pocketmine\item\GoldLeggings;

class JambieresSolarite extends GoldLeggings
{
    public function getDefensePoints(): int
    {
        return 7.5;
    }

    public function getMaxDurability(): int
    {
        return 744;
    }

    public function isUnbreakable(): bool
    {
        return false;
    }
}