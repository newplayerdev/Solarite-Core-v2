<?php


namespace NewPlayerMC\armors;


use pocketmine\item\LeatherPants;

class JambieresIterium extends LeatherPants
{
    public function getDefensePoints(): int
    {
        return 10.5;
    }

    public function getMaxDurability(): int
    {
        return 1144;
    }

    public function isUnbreakable(): bool
    {
        return false;
    }
}