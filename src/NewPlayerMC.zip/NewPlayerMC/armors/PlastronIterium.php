<?php


namespace NewPlayerMC\armors;


use pocketmine\item\LeatherTunic;

class PlastronIterium extends LeatherTunic
{
    public function getDefensePoints(): int
    {
        return 12.5;
    }

    public function getMaxDurability(): int
    {
        return 1193;
    }

    public function isUnbreakable(): bool
    {
        return false;
    }

}