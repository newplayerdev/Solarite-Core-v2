<?php


namespace NewPlayerMC\armors;


use pocketmine\item\LeatherBoots;

class BottesIterium extends LeatherBoots
{
    public function getDefensePoints(): int
    {
        return 7.5;
    }

    public function getMaxDurability(): int
    {
        return 997;
    }

    public function isUnbreakable(): bool
    {
        return false;
    }
}