<?php


namespace NewPlayerMC\armors;


use pocketmine\item\ChainLeggings;

class JambieresTopaze extends ChainLeggings
{
    public function getDefensePoints(): int
    {
        return 9;
    }

    public function getMaxDurability(): int
    {
        return 944;
    }

    public function isUnbreakable(): bool
    {
        return false;
    }
}