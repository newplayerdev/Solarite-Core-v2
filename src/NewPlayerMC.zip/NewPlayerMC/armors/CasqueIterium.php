<?php


namespace NewPlayerMC\armors;


use pocketmine\item\LeatherCap;

class CasqueIterium extends LeatherCap
{
    public function getDefensePoints(): int
    {
        return 7.5;
    }

    public function getMaxDurability(): int
    {
        return 997;
    }

    public function isUnbreakable(): bool
    {
        return false;
    }
}